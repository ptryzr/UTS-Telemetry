const express = require("express");
const mysql = require("mysql2/promise");
const cors = require("cors");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json());

// ================= STATIC =================
app.use(express.static(path.join(__dirname)));

// ================= DATABASE (POOL) =================
const db = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "",
  database: "iot_lora",
  waitForConnections: true,
  connectionLimit: 10, // 🔥 bisa paralel
  queueLimit: 0
});

console.log("✅ Database Pool Ready");

// ================= API KIRIM (SUPER CEPAT) =================
app.get("/kirim", async (req, res) => {
  try {
    let { suhu, kelembapan, ldr, soil } = req.query;

    if (!suhu || !kelembapan || !ldr || !soil) {
      return res.status(400).send("❌ Data tidak lengkap");
    }

    suhu = parseFloat(suhu);
    kelembapan = parseFloat(kelembapan);
    ldr = parseInt(ldr);
    soil = parseInt(soil);

    // 🔥 TANPA CALLBACK (LEBIH CEPAT)
    await db.execute(
      "INSERT INTO data_sensor (suhu, kelembapan, ldr, soil) VALUES (?, ?, ?, ?)",
      [suhu, kelembapan, ldr, soil]
    );

    // ⚡ langsung respon (jangan lama)
    res.send("OK");

  } catch (err) {
    console.log(err);
    res.status(500).send("ERROR");
  }
});

// ================= API AMBIL =================
app.get("/data", async (req, res) => {
  try {
    const [rows] = await db.execute(
      "SELECT * FROM data_sensor ORDER BY id DESC LIMIT 10"
    );
    res.json(rows);
  } catch (err) {
    res.status(500).send("❌ Error ambil data");
  }
});

// ================= ROUTE =================
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

// ================= RUN =================
const PORT = 3000;
app.listen(PORT, "0.0.0.0", () => {
  console.log(`🚀 Server: http://localhost:${PORT}`);
});