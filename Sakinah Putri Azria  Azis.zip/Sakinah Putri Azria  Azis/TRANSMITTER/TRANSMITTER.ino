#include <SPI.h>
#include <LoRa.h>
#include <DHT.h>

// ================== PIN ==================
#define DHTPIN 4
#define DHTTYPE DHT22

#define LDR_PIN 34
#define SOIL_PIN 35

#define SS 5
#define RST 14
#define DIO0 26

// ================== OBJECT ==================
DHT dht(DHTPIN, DHTTYPE);

// ================== SETUP ==================
void setup() {
  Serial.begin(115200);
  delay(1000);

  dht.begin();

  // Setup LoRa
  LoRa.setPins(SS, RST, DIO0);

  if (!LoRa.begin(923E6)) { // Indonesia: 923 MHz
    Serial.println("❌ LoRa Gagal!");
    while (1);
  }

  Serial.println("✅ LoRa Siap!");
}

// ================== LOOP ==================
void loop() {

  // ===== BACA DHT22 =====
  float suhu = dht.readTemperature();
  float kelembapan = dht.readHumidity();

  if (isnan(suhu) || isnan(kelembapan)) {
    Serial.println("❌ Gagal baca DHT!");
    delay(2000);
    return;
  }

  // ===== BACA SENSOR ANALOG (REAL) =====
  int ldr_raw = analogRead(LDR_PIN);
  int soil_raw = analogRead(SOIL_PIN);

  // ===== TAMPILKAN KE SERIAL =====
  Serial.println("\n===== DATA SENSOR (REAL) =====");

  Serial.print("Suhu        : ");
  Serial.print(suhu, 2);
  Serial.println(" °C");

  Serial.print("Kelembapan  : ");
  Serial.print(kelembapan, 2);
  Serial.println(" %");

  Serial.print("LDR (ADC)   : ");
  Serial.println(ldr_raw);   // nilai asli 0–4095

  Serial.print("Soil (ADC)  : ");
  Serial.println(soil_raw);  // nilai asli 0–4095

  Serial.println("==============================");

  // ===== FORMAT DATA LoRa (REAL) =====
  String data = String(suhu, 2) + "," +
                String(kelembapan, 2) + "," +
                String(ldr_raw) + "," +
                String(soil_raw);

  // ===== KIRIM DATA =====
  LoRa.beginPacket();
  LoRa.print(data);
  LoRa.endPacket();

  Serial.println("📡 Data terkirim via LoRa!");
  Serial.print("📦 Payload: ");
  Serial.println(data);

  delay(3000);
}