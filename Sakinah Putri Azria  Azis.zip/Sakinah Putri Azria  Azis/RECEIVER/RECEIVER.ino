#include <SPI.h>
#include <LoRa.h>
#include <WiFi.h>
#include <HTTPClient.h>

// ================== WIFI ==================
const char* ssid = "coba";
const char* password = "hidup1234";

// ================== SERVER ==================
String serverURL = "http://10.225.36.232:3000/kirim"; 

// ================== PIN ==================
#define SS   5
#define RST  14
#define DIO0 26

// ================== VAR ==================
String dataMasuk = "";
String rawData = "";

float suhu = 0;
float kelembapan = 0;
int ldr = 0;
int soil = 0;

// ================== SETUP ==================
void setup() {
  Serial.begin(115200);

  // ===== WIFI =====
  WiFi.begin(ssid, password);
  Serial.print("Menghubungkan WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(300);
    Serial.print(".");
  }

  Serial.println("\n✅ WiFi Terhubung!");
  Serial.println(WiFi.localIP());

  // ===== LORA =====
  LoRa.setPins(SS, RST, DIO0);

  if (!LoRa.begin(923E6)) {
    Serial.println("❌ LoRa Gagal!");
    while (1);
  }

  // 🔥 OPTIMASI CEPAT
  LoRa.setSpreadingFactor(7);
  LoRa.setSignalBandwidth(125E3);
  LoRa.setCodingRate4(5);
  LoRa.enableCrc();

  Serial.println("📡 LoRa Receiver CEPAT Siap!");
}

// ================== KIRIM SERVER (NON BLOCK) ==================
void kirimKeServerAsync(float s, float h, int l, int so) {

  HTTPClient http;

  String url = serverURL +
               "?suhu=" + String(s, 2) +
               "&kelembapan=" + String(h, 2) +
               "&ldr=" + String(l) +
               "&soil=" + String(so);

  http.begin(url);
  http.setTimeout(1000); // ⬅️ cepat timeout

  int httpCode = http.GET();

  Serial.print("🌐 HTTP: ");
  Serial.println(httpCode);

  http.end();
}

// ================== LOOP ==================
void loop() {

  int packetSize = LoRa.parsePacket();

  if (packetSize) {

    dataMasuk = "";
    rawData = "";

    while (LoRa.available()) {
      char c = (char)LoRa.read();

      rawData += c;

      if ((c >= '0' && c <= '9') || c == '.' || c == ',') {
        dataMasuk += c;
      }
    }

    Serial.println("\n📡 RAW:");
    Serial.println(rawData);

    Serial.println("🧹 CLEAN:");
    Serial.println(dataMasuk);

    // ===== PARSING =====
    float values[4];
    int index = 0;
    int lastIndex = 0;

    for (int i = 0; i < dataMasuk.length(); i++) {
      if (dataMasuk[i] == ',') {
        values[index++] = dataMasuk.substring(lastIndex, i).toFloat();
        lastIndex = i + 1;
      }
    }

    if (lastIndex < dataMasuk.length()) {
      values[index++] = dataMasuk.substring(lastIndex).toFloat();
    }

    if (index >= 3) {

      suhu = values[0];
      kelembapan = values[1];
      ldr = (int)values[2];

      if (index >= 4) soil = (int)values[3];

      Serial.println("===== DATA =====");
      Serial.println(suhu);
      Serial.println(kelembapan);
      Serial.println(ldr);
      Serial.println(soil);

      // 🔥 KIRIM CEPAT (TANPA NUNGGU LAMA)
      kirimKeServerAsync(suhu, kelembapan, ldr, soil);
    }
  }

  yield(); // biar smooth
}