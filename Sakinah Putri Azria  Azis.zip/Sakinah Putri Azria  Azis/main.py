import customtkinter as ctk
import serial
import serial.tools.list_ports
import threading
from collections import deque

import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# ================= CONFIG =================
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

plt.style.use("dark_background")

app = ctk.CTk()
app.title("Monitoring IoT LoRa")
app.geometry("1100x600")

ser = None
running = False

# ================= DATA =================
max_data = 20

suhu_data = deque(maxlen=max_data)
hum_data = deque(maxlen=max_data)
ldr_data = deque(maxlen=max_data)
soil_data = deque(maxlen=max_data)

# ================= FUNCTIONS =================
def get_ports():
    ports = serial.tools.list_ports.comports()
    return [p.device for p in ports]

def connect_serial():
    global ser, running

    port = port_combo.get()

    if port == "":
        status_label.configure(text="❌ Pilih COM dulu", text_color="red")
        return

    try:
        ser = serial.Serial(port, 115200, timeout=1)
        running = True
        threading.Thread(target=read_serial, daemon=True).start()
        status_label.configure(text=f"✅ Connected: {port}", text_color="green")
    except:
        status_label.configure(text="❌ Gagal koneksi", text_color="red")

def disconnect_serial():
    global running, ser
    running = False
    if ser:
        ser.close()
    status_label.configure(text="⛔ Disconnect", text_color="orange")

def read_serial():
    global running

    while running:
        try:
            line = ser.readline().decode().strip()
            # Format contoh: 27.9,73.8,1384,4095
            data = line.split(",")

            if len(data) == 4:
                suhu = float(data[0])
                hum = float(data[1])
                ldr = int(data[2])
                soil = int(data[3])

                suhu_data.append(suhu)
                hum_data.append(hum)
                ldr_data.append(ldr)
                soil_data.append(soil)

                # update label
                label_suhu.configure(text=f"{suhu:.2f} °C")
                label_hum.configure(text=f"{hum:.2f} %")
                label_ldr.configure(text=f"{ldr}")
                label_soil.configure(text=f"{soil}")

                # update grafik
                update_chart(ax1, line1, suhu_data)
                update_chart(ax2, line2, hum_data)
                update_chart(ax3, line3, ldr_data)
                update_chart(ax4, line4, soil_data)

        except:
            pass

# ================= CHART =================
def create_chart(frame, title, color):
    fig, ax = plt.subplots(figsize=(3,2), dpi=100)

    fig.patch.set_facecolor("#1e293b")
    ax.set_facecolor("#0f172a")

    line, = ax.plot([], [], color=color, linewidth=2, marker='o', markersize=4)

    ax.set_title(title, color="white", fontsize=10)
    ax.tick_params(colors='white', labelsize=8)

    for spine in ax.spines.values():
        spine.set_color("#334155")

    ax.grid(True, linestyle='--', alpha=0.3)

    canvas = FigureCanvasTkAgg(fig, master=frame)
    canvas.get_tk_widget().pack(fill="both", expand=True)

    return ax, line

def update_chart(ax, line, data):
    line.set_data(range(len(data)), data)

    ax.set_xlim(0, max_data)

    if len(data) > 0:
        ax.set_ylim(min(data)-5, max(data)+5)

    ax.figure.canvas.draw()

# ================= UI =================
top_frame = ctk.CTkFrame(app, fg_color="transparent")
top_frame.pack(pady=10)

port_combo = ctk.CTkComboBox(top_frame, values=get_ports(), width=120)
port_combo.pack(side="left", padx=5)

btn_connect = ctk.CTkButton(top_frame, text="Connect", command=connect_serial)
btn_connect.pack(side="left", padx=5)

btn_disconnect = ctk.CTkButton(top_frame, text="Disconnect", command=disconnect_serial)
btn_disconnect.pack(side="left", padx=5)

status_label = ctk.CTkLabel(app, text="Belum connect", text_color="yellow")
status_label.pack()

# ================= GRID =================
main_frame = ctk.CTkFrame(app, fg_color="transparent")
main_frame.pack(fill="both", expand=True)

main_frame.grid_columnconfigure((0,1,2,3), weight=1)
main_frame.grid_rowconfigure(0, weight=1)

card_color = "#1e293b"

def create_card(title, color):
    frame = ctk.CTkFrame(main_frame, fg_color=card_color, corner_radius=15)
    
    title_label = ctk.CTkLabel(frame, text=title, text_color="white")
    title_label.pack(pady=(5,0))

    value_label = ctk.CTkLabel(
        frame,
        text="0",
        font=ctk.CTkFont(size=20, weight="bold"),
        text_color=color
    )
    value_label.pack()

    chart_frame = ctk.CTkFrame(frame, fg_color="#0f172a")
    chart_frame.pack(fill="both", expand=True, padx=5, pady=5)

    return frame, value_label, chart_frame

# ================= CREATE CARD =================
frame1, label_suhu, chart1 = create_card("Suhu", "#f87171")
frame2, label_hum, chart2 = create_card("Kelembapan", "#60a5fa")
frame3, label_ldr, chart3 = create_card("LDR", "#facc15")
frame4, label_soil, chart4 = create_card("Soil", "#4ade80")

frame1.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")
frame2.grid(row=0, column=1, padx=10, pady=10, sticky="nsew")
frame3.grid(row=0, column=2, padx=10, pady=10, sticky="nsew")
frame4.grid(row=0, column=3, padx=10, pady=10, sticky="nsew")

# ================= CREATE CHART =================
ax1, line1 = create_chart(chart1, "Suhu", "#f87171")
ax2, line2 = create_chart(chart2, "Kelembapan", "#60a5fa")
ax3, line3 = create_chart(chart3, "LDR", "#facc15")
ax4, line4 = create_chart(chart4, "Soil", "#4ade80")

# ================= RUN =================
app.mainloop()